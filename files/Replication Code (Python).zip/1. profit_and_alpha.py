import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from sympy import symbols, Eq, solve, simplify



# Define symbols
p, w, p_u, alpha, delta, delta_r, c, cr, theta, lam = symbols('p w p_u alpha delta delta_r c cr theta lambda')
U_nn = (1 - lam) * (2 * (theta - p + w)) + lam * (2 * (theta - p + w + alpha))
U_n0 = theta - p + delta * theta
U_uu = delta_r * theta - p_u + delta_r * theta - p_u
theta_1 = solve(U_nn - U_n0, theta)[0]
theta_2 = solve(U_n0 - U_uu, theta)[0]
theta_3 = solve(U_uu, theta)[0]

q_nn = 1 - theta_1
q_n0 = theta_1 - theta_2
q_uu = theta_2 - theta_3
q_out = theta_3
q_m_nn = lam * q_nn

optimal_pu = cr + w
manufacturer_profit = (p - c) * (q_nn + q_nn + q_n0) - q_m_nn * alpha

def compute_optimal_p(delta_val, delta_r_val, c_val, cr_val, w_val, lam_val, alpha_val):
    manufacturer_profit_subs = manufacturer_profit.subs({p_u: optimal_pu, alpha: alpha_val})
    manufacturer_foc = Eq(manufacturer_profit_subs.diff(p), 0)
    manufacturer_solution = solve(manufacturer_foc, p)
    optimal_p_val = simplify(manufacturer_solution[0]).subs({
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val,
        lam: lam_val
    }).evalf()
    return optimal_p_val
def compute_manufacturer_profit(alpha_val, delta_val, delta_r_val, c_val, cr_val, w_val, lam_val):
    p_val = compute_optimal_p(delta_val, delta_r_val, c_val, cr_val, w_val, lam_val, alpha_val)
    return manufacturer_profit.subs({
        p: p_val,
        p_u: optimal_pu.subs({cr: cr_val, w: w_val}),
        alpha: alpha_val,
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val,
        lam: lam_val
    }).evalf()

# Define reduced parameter values for small and large delta
delta_small = 0.4  # original: delta_small= 0.4
delta_large = 0.8  # original: detla_large = 0.8
delta_r_small = 0.42 # original: delta_r_small = 0.42 / alpha is negative when delta_r_small = 0.6
delta_r_large = 0.82 # original: delta_r_large = 0.82 / alpha is negative when delta_r_large = 0.88
c_val = 0.3 # original: c_val = 0.3
cr_val = 0.0005 # original: cr_val = 0.0005
w_val = 0.24 # original: w_val = 0.24 / alpha is negative when w_val = 0.8
lam_val = 0.5 # original: lam_val = 0.5
alpha_range = np.linspace(-1, 1, 100)  # Define the range of alpha values from -1 to 1

# Calculate profits for small and large delta values across alpha range
profits_small = [float(compute_manufacturer_profit(alpha_val, delta_small, delta_r_small, c_val, cr_val, w_val, lam_val)) for alpha_val in alpha_range]
profits_large = [float(compute_manufacturer_profit(alpha_val, delta_large, delta_r_large, c_val, cr_val, w_val, lam_val)) for alpha_val in alpha_range]

# Find optimal alpha that maximizes pro
optimal_alpha_small_index = np.argmax(profits_small)
optimal_alpha_large_index = np.argmax(profits_large)

optimal_alpha_small = alpha_range[optimal_alpha_small_index]
optimal_alpha_large = alpha_range[optimal_alpha_large_index]

# Define the annagreen color
annagreen = mcolors.to_rgb((60/255, 138/255, 153/255))
default_colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
# Print optimal alpha values and corresponding profits
print(f"Optimal alpha for small delta: {optimal_alpha_small}, Profit: {profits_small[optimal_alpha_small_index]}")
print(f"Optimal alpha for large delta: {optimal_alpha_large}, Profit: {profits_large[optimal_alpha_large_index]}")

# Plotting the results with default colors and default thickness
plt.figure(figsize=(10, 6))
plt.plot(alpha_range, profits_small, label=f'Profit ($\delta^L$ = {delta_small})', color=annagreen)
plt.plot(alpha_range, profits_large, label=f'Profit ($\delta^H$ = {delta_large})', linestyle='--', color=default_colors[1])
plt.xlabel(r'Trade-in Premium ($\alpha$)')
plt.ylabel("Manufacturer's Profit ($\Pi_m$)")
plt.grid(True)
plt.axhline(0, color='black', linewidth=0.5)
plt.xlim(-0.2, 0.8)  # original: (-0.2, 1)
plt.ylim(0, 0.8)  # original: (0, 0.8)
plt.legend()

# Save the plot as a high-quality image (600 DPI) in the specified directory
save_directory = r'C:\N\OneDrive - Indiana University\Research\usedcar\Theory'
save_path = f"{save_directory}\\manufacturer_profit_vs_alpha (r_small {delta_r_small}, r_large {delta_r_large}).png"
plt.savefig(save_path, dpi=600, bbox_inches='tight')
plt.show()
















# When lambda = 1
lam_val = 1 # original: lam_val = 0.5

# Calculate profits for small and large delta values across alpha range
profits_small = [float(compute_manufacturer_profit(alpha_val, delta_small, delta_r_small, c_val, cr_val, w_val, lam_val)) for alpha_val in alpha_range]
profits_large = [float(compute_manufacturer_profit(alpha_val, delta_large, delta_r_large, c_val, cr_val, w_val, lam_val)) for alpha_val in alpha_range]

# Find optimal alpha that maximizes pro
optimal_alpha_small_index = np.argmax(profits_small)
optimal_alpha_large_index = np.argmax(profits_large)

optimal_alpha_small = alpha_range[optimal_alpha_small_index]
optimal_alpha_large = alpha_range[optimal_alpha_large_index]

# Print optimal alpha values and corresponding profits
print(f"Optimal alpha for small delta: {optimal_alpha_small}, Profit: {profits_small[optimal_alpha_small_index]}")
print(f"Optimal alpha for large delta: {optimal_alpha_large}, Profit: {profits_large[optimal_alpha_large_index]}")

# Plotting the results with default colors and default thickness
plt.figure(figsize=(10, 6))
plt.plot(alpha_range, profits_small, label=f'Profit ($\delta^L$ = {delta_small})', color=annagreen)
plt.plot(alpha_range, profits_large, label=f'Profit ($\delta^H$ = {delta_large})', linestyle='--', color=default_colors[1])
plt.xlabel(r'Trade-in Premium ($\alpha$)')
plt.ylabel("Manufacturer's Profit ($\Pi_m$)")
plt.grid(True)
plt.axhline(0, color='black', linewidth=0.5)
plt.xlim(-0.2, 0.8)  # original: (-0.2, 1)
plt.ylim(0, 0.8)  # original: (0, 0.8)
plt.legend()

# Save the plot as a high-quality image (600 DPI) in the specified directory
save_directory = r'C:\N\OneDrive - Indiana University\Research\usedcar\Theory'
save_path = f"{save_directory}\\manufacturer_profit_vs_alpha (r_small {delta_r_small}, r_large {delta_r_large}) lam_{lam_val}.png"
plt.savefig(save_path, dpi=600, bbox_inches='tight')
plt.show()

