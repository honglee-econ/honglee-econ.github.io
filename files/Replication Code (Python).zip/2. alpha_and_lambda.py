import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from sympy import symbols, Eq, solve, simplify

# Define symbols
p, w, p_u, alpha, delta, delta_r, c, cr, theta, lam = symbols('p w p_u alpha delta delta_r c cr theta lambda')
U_nn = (1 - lam) * (2 * (theta - p + w)) + lam * (2 * (theta - p + w + alpha))
U_n0 = theta - p + delta * theta
U_uu = delta_r * theta - p_u + delta_r * theta - p_u
theta_1 = solve(U_nn - U_n0, theta)[0]
theta_2 = solve(U_n0 - U_uu, theta)[0]
theta_3 = solve(U_uu, theta)[0]
q_nn = 1 - theta_1
q_n0 = theta_1 - theta_2
q_uu = theta_2 - theta_3

q_out = theta_3
q_m_nn = lam * q_nn
optimal_pu = cr + w
manufacturer_profit = (p - c) * (q_nn + q_nn + q_n0) - q_m_nn * alpha

# Function to compute optimal p for given parameters
def compute_optimal_p(delta_val, delta_r_val, c_val, cr_val, w_val, lam_val, alpha_val):
    manufacturer_profit_subs = manufacturer_profit.subs({p_u: optimal_pu, alpha: alpha_val})
    manufacturer_foc = Eq(manufacturer_profit_subs.diff(p), 0)
    manufacturer_solution = solve(manufacturer_foc, p)
    optimal_p_val = simplify(manufacturer_solution[0]).subs({
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val,
        lam: lam_val
    }).evalf()
    return optimal_p_val
# Function to compute manufacturer's profit for different alpha values
def compute_manufacturer_profit(alpha_val, delta_val, delta_r_val, c_val, cr_val, w_val, lam_val):
    p_val = compute_optimal_p(delta_val, delta_r_val, c_val, cr_val, w_val, lam_val, alpha_val)
    return manufacturer_profit.subs({
        p: p_val,
        p_u: optimal_pu.subs({cr: cr_val, w: w_val}),
        alpha: alpha_val,
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val,
        lam: lam_val
    }).evalf()

# Define the lambda range
lambda_range = np.linspace(0.01, 1, 20)  # Values between 0 (greater than 0) and 1

# Define parameter values for small and large delta
delta_small = 0.4
delta_large = 0.8
delta_r_small = 0.42
delta_r_large = 0.82
c_val = 0.3
cr_val = 0.0005
w_val = 0.24
alpha_range = np.linspace(-1, 1, 100)  # Define the range of alpha values from -1 to 1

# Function to calculate optimal alpha for given lambda
def find_optimal_alpha(delta_val, delta_r_val, c_val, cr_val, w_val, lam_val):
    profits = [float(compute_manufacturer_profit(alpha_val, delta_val, delta_r_val, c_val, cr_val, w_val, lam_val)) for alpha_val in alpha_range]
    optimal_alpha_index = np.argmax(profits)
    optimal_alpha = alpha_range[optimal_alpha_index]
    return optimal_alpha

# Calculate optimal alpha for each lambda in the range for both small and large delta
optimal_alpha_small = [find_optimal_alpha(delta_small, delta_r_small, c_val, cr_val, w_val, lam) for lam in lambda_range]
optimal_alpha_large = [find_optimal_alpha(delta_large, delta_r_large, c_val, cr_val, w_val, lam) for lam in lambda_range]

# Define the annagreen color
annagreen = mcolors.to_rgb((60/255, 138/255, 153/255))
default_colors = plt.rcParams['axes.prop_cycle'].by_key()['color']

# Plot the relationship between lambda and optimal alpha
plt.figure(figsize=(10, 6))
plt.plot(lambda_range, optimal_alpha_small, label=f'Optimal $\\alpha$ for $\\delta^L$ = {delta_small}', color=annagreen)
plt.plot(lambda_range, optimal_alpha_large, label=f'Optimal $\\alpha$ for $\\delta^H$ = {delta_large}', linestyle='--', color=default_colors[1] )
plt.xlabel(r"Share of New Car Owners Trading to Manufacturer ($\lambda$)")
plt.ylabel(r'Optimal Trade-in Premium ($\alpha$)')
plt.grid(True)
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.xlim(0, 1)  # Set x-axis range for lambda from 0 to 1
plt.ylim(0, 1.1)  # Set y-axis range for alpha
plt.legend()

# Save the plot as a high-quality image (300 DPI)
plt.savefig("alpha_vs_lambda.png", dpi=600, bbox_inches='tight')
plt.show()