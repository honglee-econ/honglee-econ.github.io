import numpy as np
import matplotlib.pyplot as plt
from sympy import symbols, Eq, solve, simplify
import matplotlib.colors as mcolors
# Define symbols
p, w, p_u, alpha, delta, delta_r, c, cr, theta, lam = symbols('p w p_u alpha delta delta_r c cr theta lambda')

# Function to compute optimal p and profit before Hyundai's entry (original model)
def compute_optimal_original(delta_val, delta_r_val, c_val, cr_val, w_val):
    # Define utilities without Hyundai's entry
    U_nn = theta - p + w + theta - p + w
    U_n0 = theta - p + delta * theta
    U_uu = delta_r * theta - p_u + delta_r * theta - p_u

    # Consumer thresholds
    theta_1 = solve(U_nn - U_n0, theta)[0]
    theta_2 = solve(U_n0 - U_uu, theta)[0]
    theta_3 = solve(U_uu, theta)[0]  # Threshold for exiting the market
    
    # Consumer segments based on updated utilities
    q_nn = 1 - theta_1  # Consumers buying a new car
    q_n0 = theta_1 - theta_2  # Consumers using the same new car into the second period
    q_uu = theta_2 - theta_3  # Consumers buying a used car
    q_out = theta_3  # Consumers leaving the market

    # Manufacturer's profit function without Hyundai's entry
    optimal_pu = cr + w
    manufacturer_profit_original = (p - c_val) * (q_nn + q_nn + q_n0)
    manufacturer_profit_original = manufacturer_profit_original.subs(p_u, optimal_pu)
    # Manufacturer's first-order condition for profit maximization with respect to p
    manufacturer_foc = Eq(manufacturer_profit_original.diff(p), 0)
    optimal_p_original = solve(manufacturer_foc, p)[0]
    optimal_p_original = optimal_p_original.subs({
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val
    }).evalf()
    
    # Substitute optimal p and return profit
    profit_original = manufacturer_profit_original.subs({
        p: optimal_p_original,
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val
    }).evalf()
    
    return optimal_p_original.evalf(), profit_original.evalf()

# Function to compute optimal p, alpha, and profit for Hyundai entry model
def compute_optimal_hyundai(delta_val, delta_r_val, c_val, cr_val, w_val, lam_val):
    # Define utilities with probabilistic influence of Hyundai's incentive
    U_nn = (1 - lam) * (2 * (theta - p + w)) + lam * (2 * (theta - p + w + alpha))  # Combined utility with Hyundai's effect
    U_n0 = theta - p + delta * theta  # Utility of not reselling to Hyundai
    U_uu = delta_r * theta - p_u + delta_r * theta - p_u  # Utility of buying a used car
    
    # Consumer thresholds
    theta_1 = solve(U_nn - U_n0, theta)[0]  # Threshold for choosing new car without selling to Hyundai
    theta_2 = solve(U_n0 - U_uu, theta)[0]  # Threshold for no resale vs. used car
    theta_3 = solve(U_uu, theta)[0]  # Threshold for exiting the market
    
    # Consumer segments based on updated utilities
    q_nn = 1 - theta_1  # Consumers buying a new car (including those selling to Hyundai)
    q_n0 = theta_1 - theta_2  # Consumers selling to the independent market
    q_uu = theta_2 - theta_3  # Consumers buying a used car
    q_out = theta_3  # Consumers leaving the market
    q_m_nn = lam * q_nn  # Fraction selling to Hyundai constrained by regulation
    
    # Profits: Hyundai pays \alpha for each car bought from the constrained segment
    optimal_pu = cr + w
    manufacturer_profit = (p - c) * (q_nn + q_nn + q_n0) - q_m_nn * alpha
    
    # Manufacturer's first-order condition for profit maximization
    manufacturer_profit_subs = manufacturer_profit.subs(p_u, optimal_pu)
    manufacturer_foc_p = Eq(manufacturer_profit_subs.diff(p), 0)
    manufacturer_foc_alpha = Eq(manufacturer_profit_subs.diff(alpha), 0)
    manufacturer_solution = solve([manufacturer_foc_p, manufacturer_foc_alpha], (p, alpha))
    
    optimal_p_hyundai = simplify(manufacturer_solution[p])
    optimal_alpha_hyundai = simplify(manufacturer_solution[alpha])

    # Extract the optimal p and alpha values
    optimal_p_hyundai = simplify(optimal_p_hyundai).subs({
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val,
        lam: lam_val
    }).evalf()
    
    optimal_alpha_hyundai = simplify(optimal_alpha_hyundai).subs({
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val,
        lam: lam_val
    }).evalf()

    # Plug optimal p and alpha into the profit function
    manufacturer_profit_hyundai_subs = manufacturer_profit_subs.subs({
        p: optimal_p_hyundai,
        alpha: optimal_alpha_hyundai,
        delta: delta_val,
        delta_r: delta_r_val,
        c: c_val,
        cr: cr_val,
        w: w_val,
        lam: lam_val
    }).evalf()

    return optimal_p_hyundai.evalf(), optimal_alpha_hyundai.evalf(), manufacturer_profit_hyundai_subs.evalf()

# Set parameters
delta_values = np.arange(0, 1, 0.1)
delta_r_values = delta_values + 0.02  # Delta_r is delta + 0.02
c_val = 0.3
cr_val = 0.0005
w_val = 0.24
lam_val = 0.5

# Store results for original model and Hyundai entry model
prices_original = []
profits_original = []
prices_hyundai = []
profits_hyundai = []
alphas_hyundai = []

# Iterate over delta and delta_r values
for delta_val, delta_r_val in zip(delta_values, delta_r_values):
    # Compute optimal p and profit for original model
    p_original, profit_original = compute_optimal_original(delta_val, delta_r_val, c_val, cr_val, w_val)

    # Compute optimal p, alpha, and profit for Hyundai entry model
    p_hyundai, alpha_hyundai, profit_hyundai = compute_optimal_hyundai(delta_val, delta_r_val, c_val, cr_val, w_val, lam_val)

    # Store the values
    prices_original.append(float(p_original))
    profits_original.append(float(profit_original))
    prices_hyundai.append(float(p_hyundai))
    profits_hyundai.append(float(profit_hyundai))
    alphas_hyundai.append(float(alpha_hyundai))
p_diff = np.array(prices_hyundai) - np.array(prices_original)


# Define custom color
custom_color_original = mcolors.to_rgb((60/255, 138/255, 153/255))
custom_color_hyundai = 'red'  # Different color for Hyundai entry
plt.figure(figsize=(10, 6))
for i in range(len(prices_original)):
    plt.annotate('', xy=(prices_hyundai[i], profits_hyundai[i]), xytext=(prices_original[i], profits_original[i]),
                 arrowprops=dict(arrowstyle='->', lw=0.65, color=custom_color_original))  # Thinner arrows with custom color    
    plt.plot(prices_original[i], profits_original[i], marker='o', color=custom_color_original, label='Original' if i == 0 else "")
    plt.plot(prices_hyundai[i], profits_hyundai[i], marker='^', color=custom_color_hyundai, label='Hyundai Entry' if i == 0 else "")
    # Modify the text to show 0 instead of 0.0
    delta_value_formatted = f'{int(delta_values[i])}' if delta_values[i] == 0 else f'{delta_values[i]:.1f}'
    plt.text(prices_original[i] - 0.01, profits_original[i] - 0.015, f'$\delta={delta_value_formatted}$', fontsize=8)
plt.xlim(0.4, 1.15)
plt.xlabel(r"New Car Price ($p^{\mathrm{old}} \longrightarrow p^{\mathrm{new}}$)", fontsize=12)
plt.ylabel(r"Manufacturer's Profit ($\Pi_m^{\mathrm{old}} \longrightarrow \Pi_m^{\mathrm{new}}$)", fontsize=12)
plt.grid(True)
plt.tight_layout()
plt.savefig("profit_vs_p.png", dpi=600, bbox_inches='tight')
plt.show()


# Create a scatter plot of alphas_hyundai on the x-axis and p_diff on the y-axis
custom_color = mcolors.to_rgb((60/255, 138/255, 153/255))
plt.figure(figsize=(10, 6))
plt.scatter(alphas_hyundai, p_diff, color=custom_color, marker='o')
for i in range(len(p_diff)):
    delta_value_formatted = f'{int(delta_values[i])}' if delta_values[i] == 0 else f'{delta_values[i]:.1f}'
    plt.text(alphas_hyundai[i], p_diff[i] + 0.01, f'$\delta={delta_value_formatted}$', fontsize=9, ha='center')
plt.xlabel("Optimal Trade-in Premium ($\\alpha$)", fontsize=12)
plt.ylabel(r"New Car Price Change ($p^{\mathrm{new}} - p^{\mathrm{old}}$)", fontsize=12)
plt.xlim(0, 0.7)
plt.ylim(0, 0.7)
plt.yticks(np.arange(0, 0.8, 0.1))
plt.xticks(np.arange(0, 0.8, 0.1))
x_range = np.linspace(0, 0.7, 100)
plt.plot(x_range, x_range, 'k-', linewidth=0.5)
plt.grid(True)
plt.tight_layout()
plt.savefig("pdiff_vs_alpha.png", dpi=600, bbox_inches='tight')
plt.show()